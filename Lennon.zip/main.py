from flask import Flask
app = Flask('app')

@app.route('/')
def main_screen(name="lennon"):
  return(name)
app.run(host='0.0.0.0', port=8080)

try:
  #if
except:
  print("An exception occurred")

"""
lis=[]
def find
dict={}
open("demofile.txt","r")
import os
os.remove
import mysql.connector
#input
#import daytime
#time=datetime.datetime.now()
tag_input=input()
#import
"""